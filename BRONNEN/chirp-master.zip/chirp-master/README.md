Chirp
=====

Javascript chiptune format and composer.

Consist of two parts:

[Player](http://chirp.rezoner.net/player/5225cdf18869503f15000004) - which can be embeded within your game

[Composer](http://chirp.rezoner.net) - create tunes online

<img src="http://i.imgur.com/IeMul4X.png" width="480">

Getting started
---

[Read the wiki](https://github.com/rezoner/chirp/wiki)

[Chirpers community](http://www.reddit.com/r/chirpers)

Current instruments
---

* Simple oscillator - simple 8-bit  like sin/saw/sqr/tri oscillator
* Soundtoy - generate samples upon mathematical formulas
* Drumkit generator - generate drums upon mathematical formulas

